﻿using Core.entities;
using EF3Data.Data;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Assignment3Entity
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            var context= new DataContext();
            /*var user = new User();
            user.Name="Test 1";
            user.Email = "lirin@gmail.com";
            user.PhoneNumber = 999309399;
            context.Users.Add(user);
            var blog= new Blog();
            blog.Url = "wwww.ggshs";
            blog.IsPublic= true;
            BlogType blogType = new BlogType();
            blogType.Name = "John";
            blogType.Description = "JSJS";
            blogType.status = Statuses.Active;
            context.blogTypes.Add(blogType);
            blog.BlogType = blogType;
            context.Blogs.Add(blog);
            var post=new Post();
            post.Title = "jdjhjsjh";
            post.Content = "kdjsjhijs";
            PostType postType= new PostType();
            postType.Name = "John";
            postType.Description = "JSJS";
            postType.status = Statuses.Active;
            context.postTypes.Add(postType);
            post.PostType = postType;
            post.Blog= blog;
            post.User= user;

            context.Posts.Add(post);
            context.SaveChanges();
            var userFound=context.Users.Include(x=>x.Posts).FirstOrDefault();
            Console.WriteLine(userFound.Name);*/

            /*var name = "Lirin Litson";
            var dataCreator = new DataCreator(name);
            var container = dataCreator.GetData();
            context.Users.AddRange(container.Users);
            context.Posts.AddRange(container.Posts);
            context.Blogs.AddRange(container.Blogs);
            context.postTypes.AddRange(container.PostTypes);
            context.blogTypes.AddRange(container.BlogTypes);
            context.SaveChanges();*/

            Console.WriteLine("Hello guys");
            var active=context.Posts.Where(post => post.PostType.status != Statuses.InActive)
                         .Where(post => post.Blog.BlogType.status != Statuses.InActive)
                         .OrderBy(post => post.User.Name).Include(x=>x.Blog.BlogType).Include(x=>x.User).Include(x=>x.PostType);
            foreach(var post in active)
            {
                Console.WriteLine("Blog Url: " + post.Blog.Url);
                Console.WriteLine("Blog IsPublic: " + post.Blog.IsPublic);
                Console.WriteLine("Blog Type Name: " + post.Blog.BlogType.Name);
                Console.WriteLine("Post User Name: " + post.User.Name);
                Console.WriteLine("Post User Email: " + post.User.Email);
                Console.WriteLine("Total Post: " + post.User.Posts.Count);
                Console.WriteLine("Post Name: " + post.PostType.Name);

            }
            Console.ReadLine();




        }
    }
}